from operations.Distance import Mdistance
from dRdd import dRdd

def KNN_Next(rdd,d,k,n,distance="Euclidean",weight="Same"): 
 data=dRdd(rdd,d,n)
 knn_last=(spark.sparkContext.broadcast(data.filter(lambda (x,y):x==n-d).collect()))
 matrix=data.mapPartitions(lambda it : Mdistance(it,knn_last,distance))
 return matrix.groupByKey().map(lambda(x,y):(list(y))).map(lambda x:mean(sorted(x)[:k],weight)).collect()


