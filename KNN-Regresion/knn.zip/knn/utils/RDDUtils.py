#Remove the string header from the RDD
#@Return an RDD without string header
def deleteHeader(idx, iter):
    output=[]
    for sublist in iter:
        output.append(sublist)
    if idx>0:
        return(output)
    else:
        return(output[1:])


def convertData(x):
	if isinstance(x, list):
		for i in range (0,len(x)):
			x[i]=float(x[i])
		return x
	else:
		return [float(x)]