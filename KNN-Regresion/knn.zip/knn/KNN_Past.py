from operations.Distance import Mdistance
from dRdd import dRdd


def KNN_Past(rdd,d,k,n,distance="Euclidean",init=400,weight="Same"):
 data=dRdd(rdd,d,n).cache()
 knn_train=(spark.sparkContext.broadcast(data.filter(lambda (x,y):x>init-d-1 and x!=n-d).collect()))
 matrix=data.mapPartitions(lambda it : Mdistance(it,knn_train,distance))
 return matrix.groupByKey().map(lambda (x,y):(x,list(y))).map(lambda(x,y):(x,sorted(y))).sortByKey().map(lambda (x,y):mean(y[:k],weight))
 